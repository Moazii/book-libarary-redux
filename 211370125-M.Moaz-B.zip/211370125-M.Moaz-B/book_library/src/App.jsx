import React from 'react';
import { useSelector } from 'react-redux';
import { Provider } from 'react-redux';
import store from './store';
import './App.css';
import AddBookForm from './components/AddBookForm';
import BookList from './components/BookList';

function App() {
  // Example usage of useState (not related to Redux)
  const [count, setCount] = React.useState(0);

  return (
    <div className='flex'>
    <div className="card bg-base-100 w-96 shadow-xl">
  <div className="card-body">
    <h2 className="card-title">Book Library Management App</h2>
    
    <Provider store={store}>
          <div className="App">
            
            <AddBookForm />
            <BookList />
          </div>
        </Provider>
    
  </div>
</div>
</div>

    
  );
}

export default App;
