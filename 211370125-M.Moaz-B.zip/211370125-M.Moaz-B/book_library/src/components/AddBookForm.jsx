import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addBook, editBook, selectAllBooks } from '../features/bookSlice';

const BookForm = ({ book }) => {
  const dispatch = useDispatch();
  const books = useSelector(selectAllBooks);

  const [title, setTitle] = useState(book ? book.title : '');
  const [author, setAuthor] = useState(book ? book.author : '');
  const [category, setCategory] = useState(book ? book.category : '');

  const handleSubmit = e => {
    e.preventDefault();
    if (book) {
      dispatch(editBook({ id: book.id, title, author, category }));
    } else {
      dispatch(addBook({ id: Date.now(), title, author, category }));
    }
    setTitle('');
    setAuthor('');
    setCategory('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input  className="input input-bordered input-primary w-full max-w-xs m-2" type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="Title" required  />
      <input className="input input-bordered input-primary w-full max-w-xs m-2 " type="text" value={author} onChange={e => setAuthor(e.target.value)} placeholder="Author" required />
      <input className="input input-bordered input-primary w-full max-w-xs m-2" type="text" value={category} onChange={e => setCategory(e.target.value)} placeholder="Category" required />
      <button  className="btn btn-outline btn-primary m-2" type="submit">{book ? 'Update' : 'Add'}</button>
    </form>
  );
};

export default BookForm;
