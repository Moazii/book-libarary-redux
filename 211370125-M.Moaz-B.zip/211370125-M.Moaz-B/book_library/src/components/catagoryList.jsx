import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { selectAllCategories, addCategory, deleteCategory } from './categorySlice';

const CategoryList = () => {
  const dispatch = useDispatch();
  const categories = useSelector(selectAllCategories);

  const handleAddCategory = () => {
    const newCategory = prompt('Enter new category:');
    if (newCategory && !categories.includes(newCategory)) {
      dispatch(addCategory(newCategory));
    }
  };

  const handleDeleteCategory = category => {
    if (window.confirm(`Are you sure you want to delete ${category}?`)) {
      dispatch(deleteCategory(category));
    }
  };

  return (
    <div>
      <h2>Categories</h2>
      <ul>
        {categories.map(category => (
          <li key={category}>
            {category}
            <button onClick={() => handleDeleteCategory(category)}>Delete</button>
          </li>
        ))}
      </ul>
      <button onClick={handleAddCategory}>Add Category</button>
    </div>
  );
};

export default CategoryList;
