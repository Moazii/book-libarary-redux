import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { selectAllBooks } from './bookSlice';

const BookSearch = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const books = useSelector(selectAllBooks);

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.author.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <input type="text" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Search by title or author" />
      <ul>
        {filteredBooks.map(book => (
          <li key={book.id}>
            {book.title} by {book.author} ({book.category})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BookSearch;
