import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { selectAllBooks, editBook, deleteBook } from '../features/bookSlice';

const BookList = () => {
  const dispatch = useDispatch();
  const books = useSelector(selectAllBooks);

  const [editMode, setEditMode] = useState(false);
  const [editedBook, setEditedBook] = useState({ id: '', title: '', author: '', borrowed: false });
  const [searchTerm, setSearchTerm] = useState('');

  const handleEdit = (book) => {
    setEditMode(true);
    setEditedBook(book);
  };

  const handleSaveEdit = () => {
    dispatch(editBook(editedBook));
    setEditMode(false);
    setEditedBook({ id: '', title: '', author: '', borrowed: false });
  };

  const handleCancelEdit = () => {
    setEditMode(false);
    setEditedBook({ id: '', title: '', author: '', borrowed: false });
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this book?')) {
      dispatch(deleteBook(id));
    }
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.author.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <h2>Book List</h2>
      <input

        type="text"
        className="input input-bordered input-primary w-full max-w-xs m-2"
        placeholder="Search by title or author"
        value={searchTerm}
        onChange={handleSearch}
      />
      <ul>
        {filteredBooks.map(book => (
          <li key={book.id}>
            {editMode && editedBook.id === book.id ? (
              <>
                <input
                  type="text"
                  className="input input-bordered input-primary w-full max-w-xs m-2"
                  value={editedBook.title}
                  onChange={(e) => setEditedBook({ ...editedBook, title: e.target.value })}
                />
                <input
                  type="text"
                  className="input input-bordered input-primary w-full max-w-xs m-2"
                  value={editedBook.author}
                  onChange={(e) => setEditedBook({ ...editedBook, author: e.target.value })}
                />
                <button className='bg-red-500 border-2 p-3 m-2 rounded-lg' onClick={handleSaveEdit}>Save</button>
                <button className='bg-red-500 border-2 p-3 m-2 rounded-lg' onClick={handleCancelEdit}>Cancel</button>
              </>
            ) : (
              <>
              <div className='flex'>
                {book.title} by {book.author}
                {book.borrowed ? ' (Borrowed)' : ' (Available)'}
                
                <button  className='bg-red-500 border-2 p-3 m-2 rounded-lg' onClick={() => handleEdit(book)}>Edit</button>
                <button className='bg-red-500 border-2 p-3 m-2 rounded-lg' onClick={() => handleDelete(book.id)}>Delete</button>
                </div>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BookList;
