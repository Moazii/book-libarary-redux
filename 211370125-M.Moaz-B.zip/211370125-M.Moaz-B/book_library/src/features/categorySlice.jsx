import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  categories: ['Fiction', 'Non-Fiction', 'Science Fiction', 'Fantasy', 'Romance'],
};

const categorySlice = createSlice({
  name: 'categories',
  initialState,
  reducers: {
    addCategory: (state, action) => {
      state.categories.push(action.payload);
    },
    deleteCategory: (state, action) => {
      state.categories = state.categories.filter(category => category !== action.payload);
    },
  },
});

export const { addCategory, deleteCategory } = categorySlice.actions;
export const selectAllCategories = state => state.categories.categories;
export default categorySlice.reducer;

