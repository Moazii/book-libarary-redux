import { configureStore } from '@reduxjs/toolkit';
import bookReducer from './features/bookSlice';
import categoryReducer from './features/categorySlice';

export default configureStore({
  reducer: {
    books: bookReducer,
    categories: categoryReducer,
  },
});
